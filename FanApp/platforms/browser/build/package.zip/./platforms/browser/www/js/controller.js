var controllers = angular.module('controllers', []);

controllers.controller('MainCtrl', function($scope, $state, UserService, $ionicLoading, $http) {

	$scope.token = "";

	$scope.initialize = function() {
		var user_id = UserService.getUserId();

		if (user_id == undefined || user_id == "") {
			var request = $http({
	        	method: "GET",
	        	url: 'http://e4c86906.ngrok.io/user_id',
	        	data: {},
	        	headers: { 'Content-Type': 'application/json' }
	    	});

	    	request.success(function(data) {
	    		UserService.setUserId(data);
	    		$scope.get_token(data);
	    	});
	    	request.error(function(error) {
	    		alert("get user_id error: " + error.message);
	    	});
		} else {
			$scope.get_token(user_id);
		}
	};

	$scope.get_token = function(user_id) {
		var request = $http({
	        method: "GET",
	        url: '	token?client=' + user_id,
	        data: {},
	        headers: { 'Content-Type': 'application/json' }
	    });
	    request.success(function(data) {
	    	$scope.token = data;
	    	$scope.after_get_token();
	    	alert("token: " + data);
	    });
	    request.error(function(error) {
	    	alert(error);
	    });
	}

	$scope.after_get_token = function() {
		Twilio.Device.setup($scope.token);

        Twilio.Device.ready(function (device) {
            alert("Ready");
        });

        Twilio.Device.error(function (error) {
            alert("Error: " + error.message);
        });

        Twilio.Device.connect(function (conn) {
            alert("Successfully established call");
            conn.accept(function (connection) {
            	alert("Connection accepted");
            })
            conn.disconnect(function (connection) {
            	alert("Connection disconnected");
            })
            conn.error(function(error) {
            	alert("Connection Error: " + error.message);
            })
        });

        Twilio.Device.incoming(function (conn) {
            conn.accept();
        });
	}

	$scope.call = function () {
		if ($scope.token == undefined || $scope.token == "") {
			alert("Token is empty.");
		} else {
			Twilio.Device.connect({"To":"fler"});
		}
	};


	$scope.initialize();
});